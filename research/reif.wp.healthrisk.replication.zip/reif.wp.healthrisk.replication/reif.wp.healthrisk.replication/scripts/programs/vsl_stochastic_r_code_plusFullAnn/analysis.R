###############################################################################
# SETUP: parse command-line arguments and set working directory
###############################################################################

args = commandArgs(trailingOnly = "TRUE")
if (length(args)) {
  wealth_nsims_input <- args[1]
  projdir <- args[2]
  outputdir <- args[3]
  
  mort_input <- args[4]
  qual_input <- args[5]
  trans_input <- args[6]
  rates_input <- args[7]
  rates_input_alt <- args[8]
  beq_input <- args[9]
  
  gamma <- as.numeric(c(args[10]))

} else {

  # Else, script is being run interactively
  projdir <- Sys.getenv("Longevity")
  outputdir <- paste(projdir,"/results/intermediate",sep="")
  
  wealth_nsims_input <- paste0(projdir,"/processed/fem/wealth_nsims.csv") 
  mort_input <- paste0(projdir,"/processed/fem/baseline_cohort_mortality.csv")  
  qual_input  <- paste0(projdir,"/processed/fem/baseline_cohort_quality.csv")
  trans_input <- paste0(projdir,"/processed/fem/baseline_cohort_transitions.csv")
  rates_input <- paste0(projdir,"/processed/fem/baseline_cohort_oopmd_return.csv")
  rates_input_alt <- paste0(projdir,"/processed/fem/baseline_cohort_s14age70_return.csv")
  
  gamma <- 1.25
}

workdir   = paste(projdir,"/scripts/programs/vsl_stochastic_r_code_plusFullAnn",sep="")
setwd(workdir)

#################################################
## PARAMETERS AND INITIALIZATIONS
#################################################
set.seed(42)

# Utility function parameters
ourgamma  <- gamma
subslevel <- 5000
intr   <- 0.03
intrho <- 0.03

# Initial age for the FEM data is 50
age <- 50


#################################################
## BASELINE SCENARIO
#################################################

#####
# Load and initialize baseline data
#####

# LOAD DATA. Note: all data should be sorted increasingly, first by health state, then age
data_mort <-  read.csv(mort_input,header = TRUE)
data_qual <-  read.csv(qual_input,header = TRUE)
data_trans <- read.csv(trans_input,header = TRUE)
data_rates <- read.csv(rates_input,header = TRUE)

# INITIALIZING DATA AND OPTIMAL SOLUTIONS
source("subroutines/VSL_data_init.R")
source("subroutines/VSL_solution_init.R")

# SOURCING ROUTINES
source("subroutines/VSL_routines.R")
source("subroutines/LE_routines.R")
source("subroutines/VFun_routines.R")
source("subroutines/Path_routines.R")
source("subroutines/Sim_routines.R")


#####
# Initial wealth for individual in state 1 with VSL of $6.83 million
#####
library(rootSolve)

# Initial wealth (seed)
w_0    <- 100000

target_vsl <- 6830000

fun <- function (x) calcVSL(50,1,x) - target_vsl
w_0_state1 <- uniroot(fun, c(w_0, 3000000))$root
write.csv(w_0_state1, file = paste(outputdir,"/w_0_state1.csv",sep=""))


#####
# Life expectancies for all ages and states
#####
number_ages <- 99-50+1
LE_qaly <- matrix(0,nrow=n_states*number_ages,ncol=4)
for (i in 1:number_ages) {
for (j in 1:n_states){
  index = (i-1)*(n_states)+j
  LE_qaly[index,1] <- i
  LE_qaly[index,2] <- j
  LE_qaly[index,3] <- calcLE(50+i-1,j)
  LE_qaly[index,4] <- calcQualAdjLE(50+i-1,j,intrate = intr)
}
}
write.csv(LE_qaly, file = paste(outputdir,"/age_state_le_qaly.csv",sep=""))

#####
# VSL simulations
#####
# Syntax: simVSL(NSIMS, age_init, state_init, wealth, type), where type is: 1=consumption, 2=VSL (default), and 3=wealth

myVSLs <- NULL
myPaths <- NULL
myWealths <- NULL

# Initial wealth in state 1
data_wealth_nsims <-  read.csv(wealth_nsims_input,header = TRUE)

for (myState in 1:n_states) {

  myWealth <- data_wealth_nsims[myState,"wealth"]
  num_sims <- data_wealth_nsims[myState,"nsims"]
  
  myResults <- simVSL(num_sims,50,myState,myWealth)
  
  myVSLs   <- rbind(myVSLs,myResults[[1]])
  myPaths  <- rbind(myPaths,myResults[[2]])
  myWealths <- rbind(myWealths,myResults[[3]])  

  ##
  # For the set of people at age 70 and still in health state 1, calculate all VSI's
  ##
  if(myState==1) {
    vsi_age <- 70
    vsi_state <- 1
  
    is_age70_state1 <- t(myResults[[2]])[vsi_age-50+1,] == vsi_state
    paths_age70_state1 <- t(myResults[[2]])[,is_age70_state1]
  
    sims_vsi <- matrix(0,n_states, ncol(paths_age70_state1))
  
    for (i in 1:ncol(paths_age70_state1)) {
    
      # Grab path and calculate wealth associated with that path (needed for calcVSI)
      my_path <- paths_age70_state1[,i]
      cons_vsl_wealth  <- calcPATH(50,my_path,data_wealth_nsims[myState,"wealth"])
    
      for (j in 1:n_states) {
      
        my_vsi <- calcVSI(vsi_age,my_path[vsi_age-50+1],j,cons_vsl_wealth[3,vsi_age-50+1])
        sims_vsi[j,i] <- my_vsi
      }
    }
    write.csv(sims_vsi, file = paste(outputdir,"/sims_vsi_age70.csv",sep=""))
  }
}
write.csv(t(myVSLs), file = paste(outputdir,"/sims_VSL_allstates.csv",sep=""))
write.csv(t(myPaths), file = paste(outputdir,"/sims_path_allstates.csv",sep=""))
write.csv(t(myWealths), file = paste(outputdir,"/sims_wealth_allstates.csv",sep=""))

###
# Consumption and VSL for person suffering two health shocks
# ----> Health state 1 for 10 years --> health state 6 for 10 years --> health state 14 for remaining years
###

# "The first shock reduces her life expectancy by 3.0 years"
# "The second one reduces her life expectancy by 6.8 years"
# "The FEM estimates that life expectancy for this sick patient is 8.5 years at age 70"
#stopifnot( abs(calcLE(60,1)-calcLE(60,6) - 3.037016)<0.0001 )
#stopifnot( abs(calcLE(70,6)-calcLE(70,14) - 6.830474)<0.0001 )
#stopifnot( abs(calcLE(70,14) - 8.505162)<0.0001 )

sickpath     <- c(rep(1,10),rep(6,10),rep(14,(max_age - age + 1)-10-10))
sickpath_cf1 <- c(rep(1,11),rep(6,9) ,rep(14,(max_age - age + 1)-11-9))
sickpath_cf2 <- c(rep(1,10),rep(6,11),rep(14,(max_age - age + 1)-10-11))

# Note: we have removed the "alt" scenario from the most recent draft
slist <- c("base", "alt")
for (scen in slist) {

	# LOAD DATA
  data_mort <-  read.csv(mort_input,header = TRUE)
  data_qual <-  read.csv(qual_input,header = TRUE)
  data_trans <- read.csv(trans_input,header = TRUE)
  
  if (scen=="base") {
    data_rates <- read.csv(rates_input,header = TRUE)
  }
  else {
    data_rates <- read.csv(rates_input_alt,header = TRUE)  
  }
  
	source("subroutines/VSL_data_init.R")
	source("subroutines/VSL_solution_init.R")

	source("subroutines/VSL_routines.R")
	source("subroutines/LE_routines.R")
	source("subroutines/VFun_routines.R")
	source("subroutines/Path_routines.R")
	source("subroutines/Sim_routines.R")

	ConsAndVSLpathSick <- calcPATH(50,sickpath,w_0_state1)
	VSLpathSick_cf1 <- calcPATH(50,sickpath_cf1,w_0_state1)[2,]
	VSLpathSick_cf2 <- calcPATH(50,sickpath_cf2,w_0_state1)[2,]
	write.csv(cbind(t(ConsAndVSLpathSick),VSLpathSick_cf1,VSLpathSick_cf2), file = paste(outputdir,"/c_vsl_w_health_shock",scen,".csv",sep=""))
}