# EVALUATING OPTIMAL SOLUTION K AND C

if (!(exists("transition"))){
  print("No init -- Running data init script")
  source("VSL_data_init.R")
}

optimalK <- matrix(0, nrow = n_states, ncol = n_ages)
optimalc <- matrix(0, nrow = n_states, ncol = n_ages)

for (j in 1:n_states){
  optimalK[j,n_ages] <- (quality[j,n_ages]^(1/ourgamma) + exp(-rates[j,n_ages]) * (exp(rates[j,n_ages] - intrho) * bequest[j,n_ages])^(1/ourgamma))^ourgamma
  optimalc[j,n_ages] <- 1/(1.0 + exp(-rates[j,n_ages]) * (exp(rates[j,n_ages]-intrho)*bequest[j,n_ages]/quality[j,n_ages])^(1/ourgamma))
}

for (i in 1:(n_ages-1)){
  for (j in 1:n_states){
    hlp <- 0
    for (k in 1:n_states){
      hlp <- hlp + optimalK[k,n_ages-i+1] * transition[j,n_ages-i,k]
    }
    hlp <- hlp * (1 - mortality[j,n_ages-i]) + bequest[j,n_ages-i] * mortality[j,n_ages-i]
    hlp <- hlp * exp(rates[j,n_ages-i] - intrho)
    
    optimalK[j,n_ages-i] <- quality[j,n_ages-i]^(1/ourgamma) + exp(-rates[j,n_ages-i]) * hlp^(1/ourgamma)
    optimalK[j,n_ages-i] <- optimalK[j,n_ages-i]^ourgamma
    
    optimalc[j,n_ages-i] <- 1/(1 + exp(-rates[j,n_ages-i]) * (hlp / quality[j,n_ages-i])^(1/ourgamma))
    
  }
}





