calcVSL <- function(init_age,init_state,wealth){
  VSL <- 0
  
  if (!(exists("ourgamma"))){
    print("No init -- Defining Standard Variables")
    ourgamma  <- 2.0
    intr   <- 0.03
    intrho <- 0.03
  }
  
  if (!(exists("transition"))){
    print("No init -- Running data init script")
    source("VSL_data_init.R")
  }
  
  if (!(exists("optimalc"))){
    print("No init -- Running calculation init script")
    source("VSL_solution_init.R")
  }
  
  if ((init_age < min_age) || (init_age > max_age)){
    print("Age not in range!")
    return(-1)
  }
  
  if ((init_state < min_state) || (init_state > max_state)){
    print("Age not in range!")
    return(-1)
  }
  
  hlp <- calcVFun(init_age,init_state,wealth)/calcVPrime(init_age,init_state,wealth)
  
  return(hlp)
  
}

calcVSI <- function(init_age,fromstate,tostate,wealth){
 
  hlp <- (calcVFun(init_age,fromstate,wealth)-calcVFun(init_age,tostate,wealth))/calcVPrime(init_age,fromstate,wealth)
  return(hlp)
  
}