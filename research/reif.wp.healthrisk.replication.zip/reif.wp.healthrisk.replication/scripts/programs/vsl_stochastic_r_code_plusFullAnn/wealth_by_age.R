###############################################################################
# SETUP: parse command-line arguments and set working directory
###############################################################################

args = commandArgs(trailingOnly = "TRUE")
if (length(args)) {
  initial_wealth <- as.numeric(args[1])
  projdir <- args[2]
	outputfile <- args[3]
	
	mort_input <- args[4]
	qual_input <- args[5]
	trans_input <- args[6]
	rates_input <- args[7]
	
	gamma <- as.numeric(args[8])

} else {

  # Else, script is being run interactively
  initial_wealth <- 862947
  projdir <- Sys.getenv(c("Longevity"))
  outputfile <- paste(projdir,"/results/output.csv",sep="")
  
  mort_input <-  paste(projdir,"/processed/fem/baseline_cohort_mortality.csv",sep="")
  qual_input <-  paste(projdir,"/processed/fem/baseline_cohort_quality.csv",sep="")
  trans_input <- paste(projdir,"/processed/fem/baseline_cohort_transitions.csv",sep="")
  rates_input <- paste(projdir,"/processed/fem/baseline_cohort_nospend_return.csv",sep="")
}

workdir   = paste(projdir,"/scripts/programs/vsl_stochastic_r_code_plusFullAnn",sep="")
setwd(workdir)

#################################################
## PARAMETERS AND INTIALIZATIONS
#################################################
set.seed(42)

# Utility function parameters
ourgamma  <- gamma
subslevel <- 5000
intr   <- 0.03
intrho <- 0.03

# Initial age for the FEM data is 50
age <- 50

# Initial wealth
w_0 <- initial_wealth


#################################################
## BASELINE SCENARIO (with no medical spending)
#################################################

#####
# Load and initialize baseline data
#####

# LOAD DATA. 
# Note: all data should be sorted increasingly, first by health state, then age
data_mort <-  read.csv(mort_input,header = TRUE)
data_qual <-  read.csv(qual_input,header = TRUE)
data_trans <- read.csv(trans_input,header = TRUE)
data_rates <- read.csv(rates_input,header = TRUE)

# INITIALIZING DATA AND OPTIMAL SOLUTIONS
source("subroutines/VSL_data_init.R")
source("subroutines/VSL_solution_init.R")

# SOURCING ROUTINES
source("subroutines/VSL_routines.R")
source("subroutines/LE_routines.R")
source("subroutines/Wealth_routines.R")
source("subroutines/VFun_routines.R")
source("subroutines/Path_routines.R")
source("subroutines/Sim_routines.R")
#source("VFunComplete_routines.R")
#source("VSLComplete_routines.R")

####
# Calculate expected wealth for person in health state 1 at age 50, by age
####

# Initial age/state: age=50, health_state=1
expected_wealth <- calcWpsi(50,1,w_0,psi=1)/(calcWpsi(50,1,w_0)+0.00000000000001)

age <- rep(0,51)
wealth <- rep(0,51)
for (i in 1:51) {
  age[i] <- 49+i
  wealth[i] <- expected_wealth[1,i]
}

write.csv(cbind(age,wealth), outputfile)

